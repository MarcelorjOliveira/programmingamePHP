<?php

namespace Pasinter\AdManagerBundle\Repository;


use Doctrine\ORM\EntityRepository;

class AdRepository extends EntityRepository
{

}