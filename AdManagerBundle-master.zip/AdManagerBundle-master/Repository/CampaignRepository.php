<?php

namespace Pasinter\AdManagerBundle\Repository;

use Doctrine\ORM\EntityRepository;

class CampaignRepository extends EntityRepository
{

}